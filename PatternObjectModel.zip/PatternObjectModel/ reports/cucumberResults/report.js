$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/java/features/Login.feature");
formatter.feature({
  "name": "Login into Leaftaps application",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Login into Leaftaps application",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "Enter username as \u003cuserName\u003e",
  "keyword": "Given "
});
formatter.step({
  "name": "Enter password as \u003cpassword\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Click the Login button",
  "keyword": "When "
});
formatter.step({
  "name": "Verify Login is Success",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "userName",
        "password"
      ]
    },
    {
      "cells": [
        "DemoSalesManager",
        "crmsfa"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Login into Leaftaps application",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Enter username as DemoSalesManager",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginPage.typeUserName(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter password as crmsfa",
  "keyword": "And "
});
formatter.match({
  "location": "LoginPage.typePassword(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click the Login button",
  "keyword": "When "
});
formatter.match({
  "location": "LoginPage.clickLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Verify Login is Success",
  "keyword": "Then "
});
formatter.match({
  "location": "HomePage.verifyLoginSuccess()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});