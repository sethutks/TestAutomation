package learning;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class AttachBrowser {
	
	@Test
	public void browserPage() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions op = new ChromeOptions();
		op.setExperimentalOption("debuggerAddress", "localhost:52433");
		ChromeDriver driver = new ChromeDriver(op);
		driver.findElementByLinkText("Create Lead").click();
		
		
		
	}
	
	
	

}
