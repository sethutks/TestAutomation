package pages;

import cucumber.api.java.en.Then;
import wrappers.SeleniumWrapper;

public class HomePageSteps extends SeleniumWrapper {

	@Then("user should be able to navigate to Home page")
	public void user_should_be_able_to_navigate_to_Home_page() {
	    System.out.println("The title of the Home page is: "+ getDriver().getTitle());
	}

}
