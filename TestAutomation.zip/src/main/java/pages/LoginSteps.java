package pages;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import wrappers.SeleniumWrapper;

public class LoginSteps extends SeleniumWrapper {
	
	@Given("User prompts the username (.*) in the Login page")
	public void enterUserName(String userName) {
		getDriver().findElementById("username").sendKeys(userName);
		
	}
	
	@Given("User prompts the password (.*) in the Login page")
	public void enterPassword(String password) {
		getDriver().findElementById("password").sendKeys(password);
		
	}

	@When("user clicks on the login button")
	public void user_clicks_on_the_login_button() throws InterruptedException {
		Thread.sleep(8000);
		getDriver().findElementByClassName("decorativeSubmit").click();
	}

}
