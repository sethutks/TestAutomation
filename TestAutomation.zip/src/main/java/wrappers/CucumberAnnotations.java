package wrappers;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class CucumberAnnotations extends SeleniumWrapper {
	
	@Before
	public void initScenario(Scenario sc) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver.set(new ChromeDriver());
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		
	}
	
	@After
	public void endScenario(Scenario sc) {
		getDriver().quit();
	}

}
