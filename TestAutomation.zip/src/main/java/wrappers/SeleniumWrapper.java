package wrappers;

import org.openqa.selenium.remote.RemoteWebDriver;

public class SeleniumWrapper {

	protected static ThreadLocal<RemoteWebDriver> driver = new ThreadLocal<>();

	public RemoteWebDriver getDriver() {
		return driver.get();
	}

}
